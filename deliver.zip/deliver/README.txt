==========================================================
 客户机 → 海外运维节点 反向连接包（2026-09-19）
==========================================================

【这是什么】
  让"客户内网的那台机器"主动连到我们的海外运维节点（38.76.202.73），
  在节点侧开一个入口。之后运维人员就能经该入口访问这台机器。

【包内文件】
  customer-reverse.sh      Linux/macOS 用（bash）
  customer-reverse.ps1     Windows 用（PowerShell）
  cust_tunnel_key          客户机专用私钥（600，别外传；丢失可让我重签）
  README.txt               本说明

【参数（已按当前环境写死，可改）】
  节点        : 38.76.202.73:22
  节点账户    : tunneld（无 shell，仅允许反向端口转发）
  节点侧入口  : 127.0.0.1:22022
  暴露端口    : 默认 22（客户机 SSH）→ 改 -ExposePort / EXPOSE_PORT 可换 3389(RDP)、80、443 等

【Linux / macOS 用法】
  chmod +x customer-reverse.sh
  ./customer-reverse.sh                       # 前台跑（先测通）
  EXPOSE_PORT=3389 ./customer-reverse.sh      # 暴露 RDP
  # 常驻（systemd 示例）：
  #   [Unit]
  #   Description=Customer Reverse Tunnel
  #   [Service]
  #   ExecStart=/opt/customer-reverse.sh
  #   Restart=always
  #   [Install]
  #   WantedBy=multi-user.target

【Windows 用法】
  1) 确认有 ssh.exe（Win10/11 自带；Win7/2008 见下）
     Get-Command ssh.exe
  2) 先前台测试：
     powershell -ExecutionPolicy Bypass -File .\customer-reverse.ps1
  3) 注册开机自启：
     powershell -ExecutionPolicy Bypass -File .\customer-reverse.ps1 -Install
  4) 暴露其它端口（例：RDP）：
     ... -Install -ExposePort 3389

  Win7 / Server 2008 没有自带 ssh：
    · 装 Win32-OpenSSH（v8.9.1.0p1-Beta，兼容 Win7）
    · 或改用 plink.exe：
        plink -N -i cust_tunnel_key.ppk -R 127.0.0.1:22022:127.0.0.1:22 tunneld@38.76.202.73

【运维侧怎么用（我方）】
  # 在 38.76.202.73 上：
  ssh -p 22022 <客户机账号>@127.0.0.1        # 若暴露的是 SSH
  # 若暴露的是 RDP：本机用 127.0.0.1:22022 连 RDP（先 ssh -L 转发出来）

【安全说明】
  · tunneld 账户已限制：no-pty / no-agent-forwarding / no-X11 / permitlisten 固定 127.0.0.1:22022
    → 客户侧拿到私钥也只能做"反向转发那一个端口"，拿不到我们节点的 shell
  · 私钥权限必须 600（Linux）/ 仅本人可读（Windows icacls）
  · 如需轮换：告诉我，我重签一对并更新节点侧公钥

【连通性要求】
  客户机需能出网访问 38.76.202.73:22（TCP）。若只允许特定端口出网，
  请告知可用端口，我把节点 SSH 或转发入口改到对应端口。

==========================================================
【补充（17:45 追加）：让运维侧直接把你配置好】
==========================================================
 本包含两套能力：

 A. 反向连接（先打通通道）
    customer-reverse.sh / .ps1
      客户机 → 38.76.202.73:22（tunneld 账户，仅端口转发）
      默认把本机 22 暴露到节点 127.0.0.1:22022

 B. 加入专网（通道打通后，由运维侧直接执行或用本机执行）
    setup-customer-node.sh      Linux：装 n2n v2.3 edge + systemd 常驻 → 10.88.0.2
    setup-customer-node.ps1     Windows：装 edge.exe + 计划任务常驻 → 10.88.0.2
      · 需要社区密钥：同目录 community.key（或 -N2nKey / N2N_KEY 传入）
      · 同目录已附 edge（Linux 静态）与 edge.exe（Windows x64）

 依赖顺序：先 A 打通隧道 → 运维侧即可 `ssh -p 22022` 进本机 → 再远程跑 B
           （也可客户本机直接跑 B，不必等我）

 结果：本机成为专网成员 10.88.0.2，运维侧经 38.76.202.73 直达本机与内网服务
