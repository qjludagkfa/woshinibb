#!/bin/bash
# ============================================================
#  customer-reverse.sh —— 客户机 → 海外运维节点 反向连接脚本（Linux/macOS）
#  作用：客户机主动外连到运维节点，并在节点侧开一个入口，
#        运维人员即可经该入口访问本机（SSH 22 / RDP 3389 / 任意端口）
#  依赖：ssh 客户端（系统自带）
# ============================================================
set -u

# ── 配置区（按需修改）──────────────────────────────
NODE_HOST="38.76.202.73"          # 海外运维节点
NODE_PORT="22"                    # 节点 SSH 端口
NODE_USER="tunneld"               # 专属隧道账户（无 shell，仅允许端口转发）
IDENTITY="$(dirname "$0")/cust_tunnel_key"   # 本包内私钥
REMOTE_BIND="127.0.0.1:22022"     # 在节点侧暴露的入口（需与节点 permitlisten 一致）
TARGET_HOST="127.0.0.1"           # 本机要暴露的服务地址
TARGET_PORT="${EXPOSE_PORT:-22}"  # 要暴露的端口：22=SSH ｜ 3389=RDP ｜ 80/443=Web ...
RETRY_DELAY=10                    # 断线重连间隔（秒）
# ────────────────────────────────────────────────

LOG="${TMPDIR:-/tmp}/customer-reverse.log"
log() { echo "[$(date '+%F %T')] $*" | tee -a "$LOG"; }

chmod 600 "$IDENTITY" 2>/dev/null || true

log "=== 反向隧道启动 ==="
log "节点      : ${NODE_USER}@${NODE_HOST}:${NODE_PORT}"
log "节点入口  : ${REMOTE_BIND}"
log "暴露目标  : ${TARGET_HOST}:${TARGET_PORT}"

while true; do
  ssh -NT \
      -o "ServerAliveInterval=30" \
      -o "ServerAliveCountMax=3" \
      -o "ExitOnForwardFailure=yes" \
      -o "StrictHostKeyChecking=accept-new" \
      -o "UserKnownHostsFile=$HOME/.ssh/known_hosts" \
      -p "$NODE_PORT" \
      -i "$IDENTITY" \
      -R "${REMOTE_BIND}:${TARGET_HOST}:${TARGET_PORT}" \
      "${NODE_USER}@${NODE_HOST}" >> "$LOG" 2>&1

  log "连接断开（退出码 $?），${RETRY_DELAY}s 后重连…"
  sleep "$RETRY_DELAY"
done
