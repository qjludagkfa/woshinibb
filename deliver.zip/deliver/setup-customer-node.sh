#!/bin/bash
# ============================================================
#  setup-customer-node.sh —— 客户机加入"海外运维专网"（Linux）
#  作用：装 n2n v2.3 edge 并以 systemd 常驻，使本机成为专网成员 10.88.0.2
#  说明：隧道打通后，运维侧可经海外节点远程执行本脚本（或客户本地执行）
# ============================================================
set -eu

COMM="cust-overseas-01"
KEY="${N2N_KEY:?需要社区密钥：export N2N_KEY='<见 community.key>'}"
SUBIP="${N2N_IP:-10.88.0.2/24}"
SUPER="38.76.202.73:7777"
BINDIR="/usr/local/bin/n2n23"
CONFDIR="/etc/n2n-cust"

echo "== 1/5 检查 root =="
[ "$(id -u)" = "0" ] || { echo "请用 root 执行"; exit 1; }

echo "== 2/5 安装 n2n v2.3 二进制 =="
mkdir -p "$BINDIR" "$CONFDIR"
if [ ! -x "$BINDIR/edge" ]; then
  if [ -f "$(dirname "$0")/edge" ]; then
    install -m 755 "$(dirname "$0")/edge" "$BINDIR/edge"
  else
    echo "  缺少 edge 二进制：请把与 n2n v2.3 同版本的 edge 放到本脚本同目录"; exit 1
  fi
fi
"$BINDIR/edge" 2>&1 | head -1 || true

echo "== 3/5 写配置 =="
cat > "$CONFDIR/edge.conf" <<EOF
# 客户专网（与运维内网隔离）
-c $COMM
-k $KEY
-a $SUBIP
-l $SUPER
-d n2ncust0
EOF
chmod 600 "$CONFDIR/edge.conf"

echo "== 4/5 注册 systemd 服务（开机自启 + 断线重连）=="
cat > /etc/systemd/system/n2n-cust-edge.service <<EOF
[Unit]
Description=n2n v2.3 edge (customer network member)
After=network-online.target
Wants=network-online.target
[Service]
Type=simple
ExecStart=$BINDIR/edge -f -c $COMM -k $KEY -a $SUBIP -l $SUPER -d n2ncust0
Restart=always
RestartSec=5
[Install]
WantedBy=multi-user.target
EOF
chmod 600 /etc/systemd/system/n2n-cust-edge.service
systemctl daemon-reload && systemctl enable --now n2n-cust-edge

echo "== 5/5 校验 =="
sleep 5
echo "  服务: $(systemctl is-active n2n-cust-edge)"
ip -o a show n2ncust0 2>/dev/null | awk '{print "  接口: "$4}'
echo "  到节点: $(ping -c 1 -W 2 -I n2ncust0 10.88.0.1 >/dev/null 2>&1 && echo 通 ✅ || echo 未通（检查 UDP 7777 出网）)"
